HW4 by Sunghyun Kim 5362318

Python version used: Conda 3.10.9
Libraries required: Numpy, random, pytorch, torchvision, matplotlib, scipy
Objective of these codes: This bunch of codes include data used to fit pca class, autoencoder, and GAN.  
How to run: Run like a normal python code 