import numpy as np

class MyPCA():
    
    def __init__(self, num_reduced_dims):

    def fit(self, X):

    def project(self, x):
