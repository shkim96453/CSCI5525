HW0 by Sunghyun Kim

Python version used: 3.10.6
Library required: Numpy
Objective of this code: It is a closed expression of ridge regression in python code. 
How to run: Run like a normal python code 
