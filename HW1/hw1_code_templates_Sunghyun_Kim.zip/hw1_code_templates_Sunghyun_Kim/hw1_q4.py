################################
# DO NOT EDIT THE FOLLOWING CODE
################################
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from my_cross_val import my_cross_val
from MyLDA import MyLDA

# load dataset
data = pd.read_csv('hw1_q4_dataset.csv', header=None).to_numpy()
X = data[:,:-1]
y = data[:,-1]

num_data, num_features = X.shape

plt.scatter(X[:1000, 0], X[:1000, 1])
plt.scatter(X[1000:, 0], X[1000:, 1])
plt.show()

# shuffle dataset
np.random.seed(2023)
perm = np.random.permutation(num_data)

X = X.tolist()
y = y.tolist()

X = [X[i] for i in perm]
y = [y[i] for i in perm]

X = np.array(X)
y = np.array(y)

# Split dataset into train and test sets
NUM_TRAIN = int(np.ceil(num_data*0.8))
NUM_TEST = num_data - NUM_TRAIN

X_train = X[:NUM_TRAIN]
X_test = X[NUM_TRAIN:]
y_train = y[:NUM_TRAIN]
y_test = y[NUM_TRAIN:]

#####################
# ADD YOUR CODE BELOW
#####################
lambda_vals = np.arange(-0.01, 0.001, 0.001)
lambda_vals = np.round(lambda_vals, 4)
for lambda_val in lambda_vals:
    print(lambda_val)
    # instantiate LDA object
    lda = MyLDA(lambda_val)
    # call to your CV function to compute error rates for each fold
    lda_err = my_cross_val(lda, 'err_rate', X, y)
    # print error rates from CV
    print ("LDA Error Rate by Fold", lda_err)
# instantiate LDA object for best value of lambda
best_lda = MyLDA(-0.003)
# fit model using all training data
best_lda.fit(X_train, y_train)
# predict on test data
best_lda.predict(X_test)
# compute error rate on test data
best_lda_err = my_cross_val(lda, 'err_rate', X_test, y_test)
# print error rate on test data
print ("LDA Error Rate by Fold, Best Lambda on Test Set", best_lda_err)
