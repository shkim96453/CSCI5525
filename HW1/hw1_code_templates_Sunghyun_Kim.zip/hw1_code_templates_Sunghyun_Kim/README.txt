HW1 by Sunghyun Kim 5362318

Python version used: 3.10.9
Libraries required: Numpy, pandas, random, matplotlib
Objective of these codes: This bunch of codes include data used to fit LDA model, cross validation function (my_cross_val.py), ridge regression class (MyRidgeRegression.py), LDA class (MyLDA.py) and test python scripts. 
How to run: Run like a normal python code 
