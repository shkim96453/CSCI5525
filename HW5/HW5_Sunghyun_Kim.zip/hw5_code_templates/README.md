HW5 by Sunghyun Kim 5362318

Python version used: Conda 3.10.9
Libraries required: Numpy, matplolib
Objective of these codes: This bunch of codes include classses used to fit epsilon greedy, UCB, and Thompson Sampling.  
How to run: Run like a normal python code 