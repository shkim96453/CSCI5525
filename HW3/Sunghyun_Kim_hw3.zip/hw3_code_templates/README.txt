HW3 by Sunghyun Kim 5362318

Python version used: Conda 3.10.9
Libraries required: Numpy, pandas, pytorch, torchvision, matplotlib
Objective of these codes: This bunch of codes include data used to fit neural network class with multiple optimizers, 
and convolutional neural networks. 
How to run: Run like a normal python code 
