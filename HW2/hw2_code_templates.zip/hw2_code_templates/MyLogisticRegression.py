import numpy as np

class MyLogisticRegression:

    def __init__(self, d, max_iters, eta):

    def fit(self, X, y):

    def predict(self, X):
    