HW2 by Sunghyun Kim 5362318

Python version used: Conda 3.10.9
Libraries required: Numpy, pandas
Objective of these codes: This bunch of codes include data used to fit logistic regression class with gradient descent, 
support vector machines class with gradient descent, cross validation function (my_cross_val.py)and test python scripts. 
How to run: Run like a normal python code 
